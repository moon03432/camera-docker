You can find pytorch2ncnn tool here

https://github.com/starimeL/PytorchConverter
